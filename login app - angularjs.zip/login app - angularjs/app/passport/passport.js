var FacebookStrategy=require('passport-facebook').Strategy;
var User=require('../models/user');
var session=require('express-session');
var jwt= require('jsonwebtoken');
var secret="mysecret";

module.exports = function(app,passport) {

		app.use(passport.initialize());
	    app.use(passport.session());
	    app.use(session({
  			secret: 'keyboard cat',
  			resave: false,
  			saveUninitialized: true,
  			cookie: { secure: false }
		}));

	    passport.serializeUser(function(user, done) {
			token=jwt.sign({username:user.username, email:user.email}, secret, {expiresIn: '24h'});
			done(null, user.id);
		});

		passport.deserializeUser(function(id, done) {
  			User.findById(id, function(err, user) {
    			done(err, user);
  			});
		});

		passport.use(new FacebookStrategy({
	    clientID: '1883320588591894',
	    clientSecret: '6e20844eff259b23f2aa4d61285dbfb2',
	    callbackURL: "http://localhost:7000/auth/facebook/callback",
	    profileFields: ['id','displayName','photos','email']
	  }, 

// 	  function(accessToken, refreshToken, profile, done) {
// // asynchronous verification, for effect...
// process.nextTick(function () {

//     User.findOne({email:profile._json.email}).select('username password email').exec(function(err,user){
//         if (err) { return done(err); }
//         if (user && user !=null) {
//         	console.log(user);
//             //create user User.create...
//             return done(null, user);
//         } else { //add this else
//             return done(err);
//         }
//     });
//   });
// 	done(null, profile);
//  }
// ));





	  function(accessToken, refreshToken, profile, done) {
	    	 console.log(profile._json.email);
	    	 User.findOne({email:profile._json.email}).select('username password email').exec(function(err,user){
	    	 	if(err) done(err);
	    	 	
	    	 	if(user && user !=null) {
//	    	 		console.log(user);
	    	 		done(null,user);
	    	 	} else {
	    	 		 return done(err);
	    	 	}
	    	});
//	    	console.log(profile);
//	    	done(null,profile);
	    }
	));











	app.get('/auth/facebook/callback', passport.authenticate('facebook', { failureRedirect: '/facebookerror' }), function(req,res){
		console.log(token);
		res.redirect('/facebook/' + token);
	});
		
	app.get('/auth/facebook', passport.authenticate('facebook', { scope: 'email' }));

	return passport;
}