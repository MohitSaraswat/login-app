angular.module('userApp',['appRoutes','userControllers','userServices','mainControllers','authServices'])

.config(function($httpProvider){
	$httpProvider.interceptors.push('AuthInterceptors');
});